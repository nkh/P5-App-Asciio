# LibAvoid Graph Viewer - Updated Version

A Perl GTK3-based interactive viewer for graph layouts with support for constraints and visual styling.

## New Features

### Dual Format Support

The viewer now supports both the original text format and a new JSON format:

**Text Format** (original):
- Requires separate input and layout files
- Syntax: `libavoid_viewer.pl input.txt layout.txt`

**JSON Format** (new):
- Single self-contained file with nodes, edges, constraints, and metadata
- Syntax: `libavoid_viewer.pl layout.json`
- Auto-detected based on file content

### Constraint-Based Visual Styling

Nodes are automatically styled based on their constraints, making constraint visualization intuitive:

| Constraint Type          | Visual Effect                                    | Default Color     |
|--------------------------|--------------------------------------------------|-------------------|
| `align_vertical`         | Light blue fill                                  | `#AED9E6`         |
| `align_horizontal`       | Light green fill                                 | `#ADE6AD`         |
| `order_left_to_right`    | Peach fill                                       | `#FFD9BA`         |
| `order_top_to_bottom`    | Lavender fill                                    | `#E6E6FA`         |
| `fixed`                  | Red outline (2px width)                          | `#FF0000`         |
| `source` (derived)       | Green outline (2px width, no incoming edges)     | `#00CC00`         |
| `sink` (derived)         | Blue outline (2px width, no outgoing edges)      | `#0000FF`         |
| `clusters`               | Translucent rounded rectangles grouping nodes    | `#BFBFBF` (30%)   |

### Automatic Format Detection

The viewer automatically detects the input format by examining the file content. You can also force a specific format using the `--format` option.

## Usage

### Basic Usage

```bash
# JSON format (auto-detected)
./libavoid_viewer.pl example_layout.json

# Text format (requires both files)
./libavoid_viewer.pl input.txt layout.txt

# Force specific format
./libavoid_viewer.pl --format=json layout.json
./libavoid_viewer.pl --format=text input.txt layout.txt
```

### Command-Line Options

```
Usage: libavoid_viewer.pl <input_file> [layout_file] [options]

Arguments:
  input_file          Input file (text format requires layout_file, JSON is self-contained)
  layout_file         Layout file (required for text format, ignored for JSON)

Options:
  -h, --help              Show this help message
  --format FORMAT         Force input format (text or json), auto-detected if not specified
  --border N              Border size in pixels (default: 10)
  --scale FACTOR          Initial scale factor
  --canvas WIDTHxHEIGHT   Initial canvas size
  --no-scale              Disable auto-scaling
  --colors FILE           Color configuration file
  --show-node-ids         Display node IDs inside nodes
  --antialias             Enable antialiasing
  --background COLOR      Background color
  --watch                 Auto-reload files when changed
```

### Keyboard Shortcuts

- `+` - Zoom in (scale by 1.5)
- `-` - Zoom out (scale by 1/1.5)
- `0` - Reset to auto-fit zoom
- `f` - Fit to window
- `q` - Quit
- Arrow keys or `h/j/k/l` - Scroll view

### Mouse Controls

- Click and drag - Pan view

## JSON Format Specification

```json
{
  "nodes": [
    {
      "id": "A",
      "x": 10.0,
      "y": 5.0,
      "width": 6.0,
      "height": 4.0
    }
  ],
  "edges": [
    {
      "source": "A",
      "target": "B",
      "route": [
        [13.0, 5.0],
        [27.0, 5.0]
      ]
    }
  ],
  "constraints": {
    "align_vertical": ["A", "C"],
    "align_horizontal": ["A", "B"],
    "order_left_to_right": ["A", "B", "D"],
    "order_top_to_bottom": ["A", "C", "D"],
    "fixed": ["A"],
    "clusters": [
      { "nodes": ["A", "B"] },
      { "nodes": ["C", "D"] }
    ],
    "grid": 1.0
  },
  "metadata": {
    "engine": {
      "layout_time_ms": 3.2,
      "routing_time_ms": 1.7,
      "node_count": 4,
      "edge_count": 4,
      "total_turns": 0,
      "routing_mode": "orthogonal"
    }
  }
}
```

### Field Descriptions

**Nodes:**
- `id` - String identifier for the node
- `x`, `y` - Top-left corner coordinates
- `width`, `height` - Node dimensions

**Edges:**
- `source`, `target` - Node IDs
- `route` - Array of `[x, y]` coordinate pairs defining the edge path

**Constraints:**
- `align_vertical` - Array of node IDs that share the same X-coordinate
- `align_horizontal` - Array of node IDs that share the same Y-coordinate
- `order_left_to_right` - Array of node IDs in left-to-right order
- `order_top_to_bottom` - Array of node IDs in top-to-bottom order
- `fixed` - Array of node IDs with fixed positions
- `clusters` - Array of cluster objects, each with a `nodes` array
- `grid` - Grid size for routing

**Metadata:**
- Optional performance and configuration information
- Not used for rendering but available for reference

## Color Customization

Create a color configuration file to override default constraint colors:

```
# Color config file
align_vertical #87CEEB
align_horizontal #90EE90
order_left_to_right #FFDAB9
order_top_to_bottom #E6E6FA
fixed #FF0000
source #00CC00
sink #0000FF
cluster #C0C0C0
background #FFFFFF
edge #3380CC
```

Use with: `./libavoid_viewer.pl layout.json --colors colors.conf`

## Examples

### View with Node IDs

```bash
./libavoid_viewer.pl example_layout.json --show-node-ids
```

### Custom Scaling

```bash
./libavoid_viewer.pl example_layout.json --scale=2.0
./libavoid_viewer.pl example_layout.json --canvas=1024x768
```

### Auto-Reload for Development

```bash
./libavoid_viewer.pl example_layout.json --watch
```

This will automatically reload the file when it changes, perfect for iterative development.

### High-Quality Rendering

```bash
./libavoid_viewer.pl example_layout.json --antialias --background=white
```

## Implementation Details

### LibAvoidRenderer Module

The `LibAvoidRenderer.pm` module provides:

- `parse_json_layout()` - Parse JSON format files
- `parse_graph_input()` - Parse traditional text format
- `parse_graph_output()` - Parse layout files
- `detect_format()` - Auto-detect file format
- `render_to_cairo()` - Render to Cairo context
- `render_png()` - Export to PNG
- `render_svg()` - Export to SVG

### Constraint Processing

1. Constraints are read from the JSON `constraints` section
2. Each node is assigned a list of applicable constraints
3. During rendering, the first constraint determines the fill color
4. Special constraints like `fixed` affect the stroke color and width
5. Source/sink status is derived from edge connectivity

### Visual Priority

When multiple constraints apply to a node, the rendering uses this priority:

1. Custom node color (if specified in color config)
2. First constraint in the node's constraint list
3. Source/sink status (derived)
4. Default color based on node ID

## Dependencies

- Perl 5.x
- GTK3 Perl bindings (`libgtk3-perl`)
- Cairo Perl bindings (`libcairo-perl`)
- JSON Perl module (`libjson-perl`)
- Glib Perl bindings (`libglib-perl`)

### Installation on Debian/Ubuntu

```bash
sudo apt-get install libgtk3-perl libcairo-perl libjson-perl libglib-perl
```

## Backward Compatibility

All existing text format files and command-line options continue to work exactly as before. The JSON format is additive and does not break any existing functionality.

## License

Same as the original LibAvoid library.
