# LibAvoid Viewer Update Summary

## Overview

The LibAvoid Graph Viewer has been updated to support the new JSON input format while maintaining full backward compatibility with the original text format.

## Key Changes

### 1. LibAvoidRenderer.pm Module

**New Functions:**
- `parse_json_layout()` - Parses the new JSON format containing nodes, edges, constraints, and metadata
- `detect_format()` - Auto-detects whether input is JSON or text format
- `get_node_color()` - Determines node fill color based on constraints
- `get_node_stroke_color()` - Determines node outline color for special constraints
- `get_node_stroke_width()` - Returns thicker outline for fixed/source/sink nodes

**Enhanced Functions:**
- `parse_graph_input()` - Now initializes constraint arrays for nodes
- `render_to_cairo()` - Uses new color/stroke functions for constraint-based styling
- `render_svg()` - Updated to support constraint-based styling
- `parse_color_config()` - Now supports constraint color overrides

**New Data Structures:**
- `%CONSTRAINT_COLORS` - Default colors for each constraint type
- Nodes now have `constraints` array and optional `string_id` field
- Graph structure includes `format`, `constraints`, and `metadata` fields

### 2. libavoid_viewer.pl Script

**New Command-Line Options:**
- `--format FORMAT` - Force format (text or json), otherwise auto-detected
- Updated help text to document both formats

**Behavior Changes:**
- Layout file is now optional (required only for text format)
- Auto-detects format from file content
- Window title shows detected format
- Watch mode handles both single-file (JSON) and dual-file (text) formats

### 3. Constraint-to-Color Mapping

Implemented the complete constraint visual styling system:

| Constraint           | Fill Color      | Stroke Effect                  |
|----------------------|-----------------|--------------------------------|
| align_vertical       | Light blue      | Standard black outline         |
| align_horizontal     | Light green     | Standard black outline         |
| order_left_to_right  | Peach           | Standard black outline         |
| order_top_to_bottom  | Lavender        | Standard black outline         |
| fixed                | Standard        | Red outline, 2px width         |
| source (derived)     | Standard        | Green outline, 2px width       |
| sink (derived)       | Standard        | Blue outline, 2px width        |
| clusters             | N/A             | Translucent rounded rectangles |

**Priority System:**
1. User-specified colors (from color config file)
2. First constraint in node's constraint list (for fill)
3. Derived source/sink status
4. Default color palette based on node ID

### 4. JSON Format Support

**Complete Implementation:**
- Parses nodes with string IDs (e.g., "A", "B", "C")
- Converts to internal numeric IDs while preserving string IDs for display
- Extracts edge routes as coordinate arrays
- Processes all constraint types
- Calculates cluster bounding boxes with padding
- Stores metadata for reference
- Derives source/sink status from edge connectivity

**Cluster Handling:**
- Automatically calculates bounding box from member nodes
- Adds 8-pixel padding around cluster bounds
- Renders with rounded corners and transparency

## Files Created/Modified

### New Files:
1. `LibAvoidRenderer.pm` - Updated module with JSON support and constraint styling
2. `libavoid_viewer.pl` - Updated viewer with format detection and dual-format support
3. `example_layout.json` - Sample JSON input file demonstrating all features
4. `example_colors.conf` - Sample color configuration file
5. `README.md` - Comprehensive documentation
6. `CHANGES.md` - This file

### Backward Compatibility

**100% Compatible:**
- All existing text format files work unchanged
- All command-line options preserved
- All keyboard shortcuts and mouse controls unchanged
- All rendering features maintained
- Original color customization system extended, not replaced

**Enhanced:**
- Format auto-detection eliminates need to specify format
- Constraint visualization adds new visual information
- Source/sink node detection provides automatic highlighting

## Usage Examples

### Text Format (Original)
```bash
./libavoid_viewer.pl input.txt layout.txt
./libavoid_viewer.pl input.txt layout.txt --show-node-ids --antialias
```

### JSON Format (New)
```bash
./libavoid_viewer.pl example_layout.json
./libavoid_viewer.pl example_layout.json --show-node-ids --colors example_colors.conf
./libavoid_viewer.pl example_layout.json --watch --antialias
```

### Force Format
```bash
./libavoid_viewer.pl --format=json layout.json
./libavoid_viewer.pl --format=text input.txt layout.txt
```

## Testing Recommendations

1. **Format Detection:**
   - Test with JSON files (should detect automatically)
   - Test with text files (should detect automatically)
   - Test --format override

2. **Constraint Visualization:**
   - Verify align_vertical nodes are light blue
   - Verify align_horizontal nodes are light green
   - Verify order constraints show correct colors
   - Verify fixed nodes have red outlines
   - Verify source nodes have green outlines
   - Verify sink nodes have blue outlines
   - Verify clusters render as translucent rounded rectangles

3. **Color Customization:**
   - Test with custom color config file
   - Verify constraint color overrides work
   - Test background color override

4. **Interactive Features:**
   - Zoom in/out with +/-
   - Pan with mouse drag
   - Fit to window with 'f'
   - Scroll with arrow keys and h/j/k/l
   - Test watch mode with file changes

5. **Edge Cases:**
   - Empty graphs
   - Single node graphs
   - Nodes with multiple constraints (should use first)
   - Nodes with no constraints
   - Invalid JSON (should error gracefully)

## Technical Notes

### Node ID Mapping
- JSON uses string IDs ("A", "B", "C")
- Internal representation uses numeric IDs
- `node_id_map` hash maintains the mapping
- `string_id` field preserves original ID for display

### Constraint Application
- Each node stores an array of applicable constraints
- Color determination checks constraints in order
- First matching constraint determines fill color
- Fixed/source/sink constraints affect outline

### Cluster Bounding Box Calculation
- Iterates through cluster member nodes
- Finds min/max X and Y coordinates
- Adds padding (8 pixels by default)
- Creates cluster rectangle for rendering

### Cairo Rendering
- Clusters drawn first (translucent, behind nodes)
- Nodes drawn with constraint-based colors
- Ports drawn on top of nodes
- Edges and arrows drawn last
- Text labels drawn if enabled

## Dependencies

Required Perl modules:
- Cairo (for rendering)
- Gtk3 (for GUI)
- Glib (for event handling)
- JSON (for JSON parsing)
- Getopt::Long (built-in)
- FindBin (built-in)

## Future Enhancement Possibilities

1. **Additional Constraint Types:**
   - Could add visualization for more constraint types
   - Edge-specific constraints
   - Node groupings beyond clusters

2. **Export Features:**
   - Export current view to PNG/SVG
   - Batch rendering mode
   - Animation support for layout evolution

3. **Interactive Editing:**
   - Click nodes to see constraint details
   - Toggle constraint visibility
   - Constraint editor mode

4. **Performance:**
   - Optimize for very large graphs
   - Level-of-detail rendering
   - Caching for complex scenes

## Conclusion

The updated viewer successfully integrates JSON format support while maintaining complete backward compatibility. The constraint-based visual styling provides immediate visual feedback about the graph's structural constraints, making it easier to understand and debug complex layouts.
